import "./App.css";
import { GameScreen } from "./components/GameScreen/GameScreen";

function App() {
  return (
    <div className="App">
      <GameScreen />
    </div>
  );
}

export default App;
